package com.example.codeclan.recruitment.models;

public class Client {
}
