package com.example.codeclan.recruitment.repositories;

import com.example.codeclan.recruitment.models.Job;

import java.util.List;

public interface JobRepositoryCustom {

    List<Job> getAllJobs();
}
