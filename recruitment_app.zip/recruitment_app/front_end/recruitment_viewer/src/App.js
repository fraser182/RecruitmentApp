import React, { Component } from 'react';
import MainContainer from './containers/Main/MainContainer.js';


class App extends Component {
  render() {
    return (


      <MainContainer />


    );
  }
}

export default App;
