// import React from 'react';
// import {Link} from 'react-router-dom';
// import './css/HeaderContainer.css';
//
// const NavBar = ({ onSelect }) => {
//   return (
//       <ul>
//         <li className="navLink">
//           <Link to="/jobs/new" onClick={onSelect}>Post A Job</Link>
//         </li>
//         <li className="navLink">
//           <Link to="#" onClick={onSelect}>Pricing</Link>
//         </li>
//         <li className="navLink">
//           <Link to="/about" onClick={onSelect}>About</Link>
//         </li>
//         <li className="navLink">
//           <Link to="#" onClick={onSelect}>Contact</Link>
//         </li>
//       </ul>
//   )
// }
//
// export default NavBar;
