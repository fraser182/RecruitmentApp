import React, {Component} from 'react';
import '../../css/FooterContainer.css';

class FooterContainer extends Component {

  render(){
    return(
      <div className="footer-container">
      <h2>Footer Container</h2>
      </div>

    )
  }

}

export default FooterContainer;
